# BATCH_007 — Weapon HUD icons for the starter guns + stolen tail

1. เปิดแชตใหม่ใน ChatGPT แนบ `00_START_HERE_FOR_CHATGPT.md` ให้อ่านก่อน
2. แนบ `BATCH_007.md` พร้อมภาพทั้งหมดในโฟลเดอร์ `references/`
3. ให้สร้างทีละภาพตามลำดับ ใช้ชื่อไฟล์ตามที่กำหนด
4. ได้ครบแล้วรวมเป็น ZIP ส่งกลับมาให้ Claude ตรวจและใส่เข้าเกม
