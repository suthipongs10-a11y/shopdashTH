# BATCH_002 — ไอคอน Power Up 12 แบบ

1. เปิดแชตใหม่ใน ChatGPT แนบ `00_START_HERE_FOR_CHATGPT.md` ให้อ่านก่อน
2. แนบ `BATCH_002.md` พร้อมภาพอ้างอิง `references/powerups_board.jpg` และ `references/gameplay_powerup.jpg`
3. ให้สร้างทีละภาพ 12 ภาพ ชื่อไฟล์ `rb_pickup_pu01_000.png` … `rb_pickup_pu12_000.png` พื้นหลังโปร่งใสจริง
4. ได้ครบแล้วรวมเป็น ZIP ส่งกลับมาให้ Claude ตรวจและใส่เข้าเกม

หมายเหตุ: ไอคอน "ยิงสามทาง" (PU01) ต้องมีกระสุน **3 ลูก** ตามกติกาเกม (บอร์ดตัวอย่างวาด 4 ลูก)
